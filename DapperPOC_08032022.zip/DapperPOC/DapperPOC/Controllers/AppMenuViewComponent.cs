﻿using DapperPOC.Repository;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DapperPOC.Controllers
{
    [ViewComponent]
    public class AppMenuViewComponent: ViewComponent
    {
        private readonly ICompanyRepository _componyRepo;
        public AppMenuViewComponent(ICompanyRepository componyRepo)
        {
            _componyRepo = componyRepo;
        }
        public async Task<IViewComponentResult> InvokeAsync(
         int maxPriority, bool isDone)
        {
            var appMenu = _componyRepo.GetAppMenus();
            return View(appMenu);
        }
    }
}
