﻿using DapperPOC.Data;
using DapperPOC.Models;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Dapper;
using DapperPOC.ViewModels;

namespace DapperPOC.Repository
{
    public class CompanyRepository : ICompanyRepository
    {
        private IDbConnection database;
        public CompanyRepository(IConfiguration configuration)
        {
            this.database = new SqlConnection(configuration.GetConnectionString("DefaultConnection"));
        }
        public Company AddCompany(Company company)
        {
            //var sqlQuery = "INSERT INTO Companies (Name, Address, City, State, PostalCode) VALUES(@Name, @Address, @City, @State, @PostalCode);"
            //    + "SELECT CAST(SCOPE_IDENTITY() as int); ";
            //var companyId = database.Query<int>(sqlQuery, company).Single();
            var companyId = database.Query<int>("ADDCOMPANY", company, commandType: CommandType.StoredProcedure).Single();
            company.CompanyId = companyId;
            return company;
        }

        public void DeleteCompany(int companyId)
        {
            var sqlQuery = "DELETE FROM Companies WHERE CompanyId = @CompanyId";
            database.Execute(sqlQuery, new { @CompanyId = companyId });
        }

        public Company Find(int companyId)
        {
            var sqlQuery = "SELECT * FROM Companies WHERE CompanyId = @CompanyId";
            return database.Query<Company>(sqlQuery, new { @CompanyId = companyId }).Single();
        }

        public List<Company> GetCompanies()
        {
            //var sqlQuery = "SELECT * FROM Companies";
            //return database.Query<Company>(sqlQuery).ToList();

            return database.Query<Company>("GETCOMAPNIES", commandType: CommandType.StoredProcedure).ToList();
        }

        public Company UpdateCompany(Company company)
        {
            var sqlQuery = "UPDATE Companies SET Name=@Name, Address= @Address, City=@City, State=@State, PostalCode=@PostalCode WHERE CompanyId = @CompanyId";
            database.Execute(sqlQuery, company);
            return company;
        }

        public List<AppMenuVM> GetAppMenus()
        {
            var sqlQuery = "SELECT * FROM AppMenu WHERE isActive=1";
            var lstMenu = database.Query<AppMenu>(sqlQuery).ToList();
            return ConvertAppMenu(lstMenu);
        }

        public List<FAQVM> GetFAQs()
        {
            var sqlQuery = "SELECT * FROM FAQ";
            var lstFAQ = database.Query<FAQ>(sqlQuery).ToList();
            return ConvertFAQList(lstFAQ);
        }

        public bool AddQuestion(FAQVM faqDetails)
        {
            var sqlQuery = "Insert Into FAQ(Question) Values(@Question)";
            int result = database.Execute(sqlQuery, faqDetails);
            return result > 0;
        }

        public FAQVM GetQuestion(int questionId)
        {
            var sqlQuery = "Select * from FAQ WHERE FAQID=@questionId";
            FAQ faq = database.Query<FAQ>(sqlQuery, new { questionId }).FirstOrDefault();
            return ConvertFAQ(faq);
        }

        public bool UpdateQuestion(FAQVM faqDetails)
        {
            var sqlQuery = "Update FAQ Set Question=@Question, Answer=@Answer, ViewName=@ViewName where FAQID=@FAQID";
            int result = database.Execute(sqlQuery, faqDetails);
            return result > 0;
        }

        private List<AppMenuVM> ConvertAppMenu(List<AppMenu> lstMenu)
        {
            List<AppMenuVM> lstMenus = new List<AppMenuVM>();
            var lstMainMenu = lstMenu.Where(m => m.MainMenuId == null).ToList();
            var lstSubMenus = lstMenu.Where(m => m.MainMenuId != null).ToList();
            foreach (var menu in lstMainMenu)
            {
                AppMenuVM appMenu = new AppMenuVM()
                {
                    MenuId = menu.MenuId,
                    DisplayName = menu.DisplayName,
                    DefaultURL = menu.DefaultURL,
                    DisplayIcon = menu.DisplayIcon,
                    LstSubMenus = new List<AppSubMenuVM>()
                };

                foreach (var subMenu in lstSubMenus.Where(n => n.MainMenuId == menu.MenuId))
                {
                    appMenu.LstSubMenus.Add(new AppSubMenuVM()
                    {
                        SubMenuId = subMenu.MenuId,
                        DisplayName = subMenu.DisplayName,
                        DefaultURL = subMenu.DefaultURL,
                        DisplayIcon = subMenu.DisplayIcon
                    });
                }
                lstMenus.Add(appMenu);
            }

            return lstMenus;
        }

        private List<FAQVM> ConvertFAQList(List<FAQ> lstFAQ)
        {
            List<FAQVM> lstFAQVM = new List<FAQVM>();
            foreach (var item in lstFAQ)
            {
                FAQVM faq = new FAQVM()
                {
                    FAQID = item.FAQID,
                    ViewName = item.ViewName,
                    Question = item.Question,
                    Answer = item.Answer
                };
                lstFAQVM.Add(faq);
            }
            return lstFAQVM;
        }

        private FAQVM ConvertFAQ(FAQ faq)
        {
            FAQVM fAQVM = new FAQVM()
            {
                FAQID = faq.FAQID,
                ViewName = faq.ViewName,
                Question = faq.Question,
                Answer = faq.Answer
            };
            return fAQVM;
        }
    }
}
