﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DapperPOC.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace DapperPOC.Controllers
{
    [ViewComponent]
    public class AddQuestionViewComponent : ViewComponent
    {
        public async Task<IViewComponentResult> InvokeAsync(
         int maxPriority, bool isDone)
        {
            FAQVM faq = new FAQVM();
            return View(faq);
        }
    }
}
