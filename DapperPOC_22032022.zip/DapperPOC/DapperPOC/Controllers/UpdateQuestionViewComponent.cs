﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DapperPOC.Repository;

namespace DapperPOC.Controllers
{
    [ViewComponent]
    public class UpdateQuestionViewComponent: ViewComponent
    {
        private readonly ICompanyRepository _componyRepo;
        public UpdateQuestionViewComponent(ICompanyRepository componyRepo)
        {
            _componyRepo = componyRepo;
        }
        public async Task<IViewComponentResult> InvokeAsync(
         int maxPriority, bool isDone,int questionId)
        {
            var faqDetails = _componyRepo.GetQuestion(questionId);
            return View(faqDetails);
        }
    }
}
