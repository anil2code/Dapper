﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DapperPOC.ViewModels
{
    public class FAQVM
    {
        public int FAQID { get; set; }
        public string ViewName { get; set; }
        [Required(ErrorMessage = "Please Enter Question")]
        public string Question { get; set; }
        [RequireWhenUpdate]
        public string Answer { get; set; }
    }

    public class RequireWhenUpdate : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var faq = (FAQVM)validationContext.ObjectInstance;
            if (faq.FAQID > 0)
                return new ValidationResult("Please Enter Answer");
            else
                return ValidationResult.Success;
        }
    }
}
