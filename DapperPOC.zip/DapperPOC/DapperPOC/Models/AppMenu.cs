﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DapperPOC.Models
{
    public class AppMenu
    {
        public int MenuId { get; set; }
        public string Component { get; set; }
        public string AppName { get; set; }
        public string DisplayName { get; set; }
        public string AppDescription { get; set; }
        public string DisplayStyle { get; set; }
        public string DefaultURL { get; set; }
        public string DisplayInTopBar { get; set; }
        public byte isActive { get; set; }
        public string DisplayIcon { get; set; }
    }
}
