﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DapperPOC.ViewModels
{
    public class AppMenuVM
    {
        public int MenuId { get; set; }
        public string DisplayName { get; set; }
        public string DisplayIcon { get; set; }
        public string DefaultURL { get; set; }
        public List<AppSubMenuVM> LstSubMenus { get; set; }
    }

    public class AppSubMenuVM
    {
        public int SubMenuId { get; set; }
        public string DisplayName { get; set; }
        public string DisplayIcon { get; set; }
        public string DefaultURL { get; set; }
    }


}
