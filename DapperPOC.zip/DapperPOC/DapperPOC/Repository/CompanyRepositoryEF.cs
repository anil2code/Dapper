﻿using DapperPOC.Data;
using DapperPOC.Models;
using DapperPOC.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DapperPOC.Repository
{
    public class CompanyRepositoryEF : ICompanyRepository
    {
        private readonly ApplicationDbContext _context;
        public CompanyRepositoryEF(ApplicationDbContext _context)
        {
            this._context = _context;
        }
        public Company AddCompany(Company company)
        {
            _context.Add(company);
            _context.SaveChanges();
            return company;
        }

        public void DeleteCompany(int companyId)
        {
            Company company = _context.Companies.FirstOrDefault(m => m.CompanyId == companyId);
            _context.Remove(company);
            _context.SaveChanges();
        }

        public Company Find(int companyId)
        {
            return _context.Companies.FirstOrDefault(m => m.CompanyId == companyId);
        }

        public List<Company> GetCompanies()
        {
            return _context.Companies.ToList();
        }

        public Company UpdateCompany(Company company)
        {
            _context.Companies.Update(company);
            _context.SaveChanges();
            return company;
        }

        public List<AppMenuVM> GetAppMenus()
        {
            var lstMenu = _context.AppMenu.ToList();
            return ConvertAppMenu(lstMenu);
        }

        private List<AppMenuVM> ConvertAppMenu(List<AppMenu> lstMenu)
        {
            List<AppMenuVM> lstMenus = new List<AppMenuVM>();
            var lstMainMenu = lstMenu.Where(m => m.MainMenuId == null).ToList();
            var lstSubMenus = lstMenu.Where(m => m.MainMenuId != null).ToList();
            Parallel.ForEach(lstMainMenu, menu =>
            {
                AppMenuVM appMenu = new AppMenuVM()
                {
                    MenuId = menu.MenuId,
                    DisplayName = menu.DisplayName,
                    DefaultURL = menu.DefaultURL,
                    DisplayIcon = menu.DisplayIcon,
                    LstSubMenus = new List<AppSubMenuVM>()
                };

                Parallel.ForEach(lstSubMenus.Where(n => n.MainMenuId == menu.MenuId), subMenu =>
                {
                    appMenu.LstSubMenus.Add(new AppSubMenuVM()
                    {
                        SubMenuId = subMenu.MenuId,
                        DisplayName = subMenu.DisplayName,
                        DefaultURL = subMenu.DefaultURL,
                        DisplayIcon = subMenu.DisplayIcon
                    });
                });
            });

            return lstMenus;
        }
    }
}
